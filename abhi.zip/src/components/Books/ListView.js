import React from "react";
import styled from "styled-components";
import { books } from "./../../data/books";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TablePagination from "@material-ui/core/TablePagination";
import TableRow from "@material-ui/core/TableRow";
import TableSortLabel from "@material-ui/core/TableSortLabel";
const Header = styled.div`
  width: 100%;
`;
const ListView = (props) => {
  const headCells = [
    {
      id: "name",
      numeric: false,
      disablePadding: true,
      label: "Book Title & Author",
    },
    { id: "genre", numeric: true, disablePadding: false, label: "Genre" },
    {
      id: "progress",
      numeric: true,
      disablePadding: false,
      label: "Reading Progress",
    },
    {
      id: "opened",
      numeric: true,
      disablePadding: false,
      label: "Last Opened",
    },
  ];
  return (
    <>
      <TableHead>
        <TableRow>
          {headCells.map((headCell) => (
            <TableCell
              key={headCell.id}
              align={headCell.numeric ? "right" : "left"}
              padding={headCell.disablePadding ? "none" : "default"}
              //   sortDirection={orderBy === headCell.id ? order : false}
            >
              <TableSortLabel
              // active={orderBy === headCell.id}
              // direction={orderBy === headCell.id ? order : "asc"}
              // onClick={createSortHandler(headCell.id)}
              >
                {headCell.label}
                {/* {orderBy === headCell.id ? (
                  <span className={classes.visuallyHidden}>
                    {order === "desc"
                      ? "sorted descending"
                      : "sorted ascending"}
                  </span>
                ) : null} */}
              </TableSortLabel>
            </TableCell>
          ))}
        </TableRow>
      </TableHead>
      {books.map((book, index) => {
        return <div>{book.title}</div>;
      })}
    </>
  );
};
export default ListView;
