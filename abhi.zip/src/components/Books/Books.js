import React, { useState, useContext } from "react";
import { Book } from "./Book";
import { ModalContext } from "./../../context/ModalContext";
export default function Books({ books }) {
  const { mode } = useContext(ModalContext);
  return books.map((book, index) => {
    return (
      <div key={index}>
        <Book
          image={book.image}
          isModalOpen={false}
          key={index}
          id={index}
          title={book.title}
          read_percentage={book.read_percentage}
          genre={book.genre}
          description={book.description}
          author={book.author}
        />
        <div style={styles.book__details}>
          <h3>{book.title.substr(0, 20)}... </h3>
          <p>{book.author}</p>
        </div>
      </div>
    );
  });
}

const styles = {
  book__details: {
    marginLeft: "20px",
  },
};
