import React, { useContext } from "react";
import "./nav.css";
import { BsGrid, BsList, BsSearch } from "react-icons/bs";
import { ModalContext } from "./../../context/ModalContext";
export default function Nav(props) {
  const { setMode } = useContext(ModalContext);
  return (
    <div className="nav__container">
      <h2>Book Library ...</h2>
      <div className="nav__ontainer-icons">
        <BsGrid
          onClick={() => setMode("grid")}
          size={24}
          style={{
            padding: "10px",
            borderRadius: "10px",
            backgroundColor: "#F0F0F0",
            marginRight: "10px",
          }}
        />
        <BsList
          onClick={() => setMode("list")}
          size={24}
          style={{
            padding: "10px",
            borderRadius: "10px",
            backgroundColor: "#F0F0F0",
            marginRight: "10px",
          }}
        />
        <i style={{ position: "absolute", padding: "10px" }}>
          <BsSearch size={24} className="search__icon" />
        </i>
        <input className="extand" type="text" />
      </div>
    </div>
  );
}
