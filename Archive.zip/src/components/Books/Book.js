import React from "react";
import styled from "styled-components";
const BookStyle = styled.div`
  color: palevioletred;
  font-size: 1em;
  margin: 1em;
  height: 350px;
  width: 200px;
  padding: 0.25em 1em;
  border-radius: 10px;
  background-image: url(${(props) => props.background || "palevioletred"});
  background-repeat: no-repeat;
  background-size: cover;
`;

export const Book = (props) => {
  console.log("Book", props.image);
  return <BookStyle background={props.image}>{props.title}</BookStyle>;
};
