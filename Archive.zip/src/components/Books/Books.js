import React from "react";
import { Book } from "./Book";
export default function Books({ books }) {
  return (
    <div>
      {books.map((book, index) => {
        return (
          <>
            <Book image={book.image} key={index} />
            <h3>{book.title.substr(0, 20)}... </h3>
            <p>{book.author}</p>
          </>
        );
      })}
    </div>
  );
}
