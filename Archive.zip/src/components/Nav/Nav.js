import React from "react";
import "./nav.css";
import { BsGrid, BsList, BsSearch } from "react-icons/bs";
export default function Nav() {
  return (
    <div className="nav__container">
      <h2>Book Library ...</h2>
      <div className="nav__ontainer-icons">
        <BsGrid
          size={24}
          style={{
            padding: "10px",
            borderRadius: "10px",
            backgroundColor: "#F0F0F0",
            marginRight: "10px",
          }}
        />
        <BsList
          size={24}
          style={{
            padding: "10px",
            borderRadius: "10px",
            backgroundColor: "#F0F0F0",
            marginRight: "10px",
          }}
        />
        <i style={{ position: "absolute", padding: "10px" }}>
          <BsSearch size={24} className="search__icon" />
        </i>
        <input className="extand" type="text" />
      </div>
    </div>
  );
}
