import React, { useContext } from "react";
import "./nav.css";
import { BsGrid, BsList, BsSearch } from "react-icons/bs";
import { ModalContext } from "./../../context/ModalContext";
import styled from "styled-components";

const NavContainer = styled.div`
  height: 50px;
  width: 90%;
  display: flex;
  justify-content: space-between;
  text-align: center;
  align-items: center;
  padding: 30px;
  border-bottom: 1px solid #ccc;
  border-radius: 10px;
  margin-left: 2%;
`;

const NacContainerIcons = styled.div`
  display: flex;
  justify-content: flex-end;
`;
export default function Nav() {
  const { setMode, setSearch } = useContext(ModalContext);
  const showFiltered = (e) => {
    setSearch(e.target.value);
  };
  return (
    <NavContainer>
      <h2>Book Library ...${({ theme }) => theme.toggleBorder}</h2>
      <NacContainerIcons>
        <BsGrid
          onClick={() => setMode("grid")}
          size={24}
          style={{
            padding: "10px",
            borderRadius: "10px",
            border: `1px solid ${({ theme }) => theme.toggleBorder}`,
            backgroundColor: `${({ theme }) => theme.toggleBorder}`,
            marginRight: "10px",
          }}
        />
        <BsList
          onClick={() => setMode("list")}
          size={24}
          style={{
            padding: "10px",
            borderRadius: "10px",
            border: `1px solid ${({ theme }) => theme.background}`,
            backgroundColor: `${({ theme }) => theme.background}`,
            marginRight: "10px",
          }}
        />

        <input
          className="extand"
          type="text"
          onChange={(e) => {
            showFiltered(e);
          }}
        />
      </NacContainerIcons>
    </NavContainer>
  );
}
